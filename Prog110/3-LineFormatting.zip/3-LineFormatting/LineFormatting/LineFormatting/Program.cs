﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LineFormatting
{
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("Please enter your age:");
            string userInput = Console.ReadLine();

            int userInputInt = Convert.ToInt32(userInput);

            userInputInt = userInputInt + 1;

            string userOutput = userInputInt.ToString();

            Console.WriteLine(userOutput);

            Console.WriteLine(userInputInt);

            Console.ReadLine();


            int num1 = 4, num2 = 56, num3 = 789;

            // no formatting
            Console.WriteLine("First number is {0} more text", num1);
            Console.WriteLine("Second number is {0} more text", num2);
            Console.WriteLine("Third number is {0} more text", num3);
            Console.ReadLine();

            // trying out the the format string with its right aligned placeholder and substitutions
            // with an alignment of 10 the resulting string will always be 10 characters even if the number only took up 3 places.
            Console.WriteLine("First number is {0, 10} more text", num1);
            Console.WriteLine("Second number is {0, 9} more text", num2);
            Console.WriteLine("Third number is {0, 10} more text", num3);
            Console.ReadLine();

            // trying out the the format string with its left aligned placeholder
            Console.WriteLine("First number is {0, -10} more text", num1);
            Console.WriteLine("Second number is {0, -9} more text", num2);
            Console.WriteLine("Third number is {0, -10} more text", num3);
            Console.ReadLine();

            //concatenate with the + not a CR
            Console.WriteLine("First number is {0, 2} " +
            "Second number is {1, 3} " +
            "Third number is {2, 4} ",
            num1, num2, num3);

            int one = 45;
            int two = 2;

            int answ = one / two;
            Console.WriteLine(answ);
            answ = one % two; 

            Console.WriteLine(answ);
            Console.ReadLine();
        }
    }
}
