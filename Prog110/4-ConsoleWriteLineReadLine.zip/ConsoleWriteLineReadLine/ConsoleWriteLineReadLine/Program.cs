﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleWriteLineReadLine
{

    class Dog
    {
        public string Color { get; set; }
        public int Weight { get; set; }
    }

    class Program
    {
        static void Main(string[] args)
        {
            int someInt = 4;
            double someDouble = 4.5f;
            string someString = "someString";
            int[] someArray = new int[3] { 22, 33, 44 };
            Dog someDog = new Dog();
            someDog.Color = "black and white";
            someDog.Weight = 49;

            Console.WriteLine(someInt);
            Console.WriteLine(someDouble);
            Console.WriteLine(someString);
            Console.WriteLine(someArray);
            Console.WriteLine(someDog);

            Console.WriteLine();

            Console.WriteLine(someInt + someDouble + someString + someArray + someDog);

            Console.WriteLine();

            Console.WriteLine(someInt.ToString());
            Console.WriteLine(someDouble.ToString());
            Console.WriteLine(someString.ToString());
            Console.WriteLine(someArray.ToString());
            Console.WriteLine(someDog.ToString());

            Console.WriteLine();

            Console.WriteLine(someInt.ToString() + someDouble.ToString() + someString.ToString() + someArray.ToString() + someDog.ToString());


            //int someInt2 = Console.ReadLine();
            //double someDouble2 = Console.ReadLine();
            //string someString2 = Console.ReadLine();
            //int[] someArray2 = Console.ReadLine();
            //Dog someDog2 = Console.ReadLine(); ;

            Console.ReadLine();


        }
    }
}
